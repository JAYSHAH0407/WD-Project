Requirements
	PHP 5.5
	MySQL 5 database

Database Name : moviebook

Features:
1. Login / Logout for customer.
2. Seperate login for admin (location/hms-admin) - username: admin, password: admin
3. online  manualy seat book
4. payment method
5. admin can Movie,Time,User etc. "add edit delete and select"
6. admin can Manage the user and payment history
7. Best Logical php code i

Note: 
1. This project is for college and study only
2. that is not use for Commercial project
