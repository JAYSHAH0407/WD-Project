# online-movie-booking
I doveloped this project using Core PHP,HTML,JavaScript,CSS,Bootstrap.

# Note
1. This project is for college and study only
2. that is not use for Commercial project

# Screenshot

## 1. Home page ##
![home1](https://user-images.githubusercontent.com/104883953/167260990-670d3197-5c62-44bc-b821-fcc8d0efd36d.jpg)
![home2](https://user-images.githubusercontent.com/104883953/167261156-947f1206-6d2f-48c5-b3ba-319ff50b2e95.jpg)

## 2. All Movie ##
![all movie](https://user-images.githubusercontent.com/104883953/167261026-0c6d020e-7963-4e33-85e9-97b2b118d2e6.jpg)

## 3. Seat Book ##
![seat book](https://user-images.githubusercontent.com/104883953/167261039-e45bb084-ed5a-4b43-b8d2-132a16100d41.jpg)

